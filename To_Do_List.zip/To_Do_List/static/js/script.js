document.getElementById("taskForm").addEventListener("submit", function(event) {
    event.preventDefault();
    var taskInput = document.getElementById("taskInput");
    var taskList = document.getElementById("taskList");
    var taskText = taskInput.value.trim();
    if (taskText !== "") {
        var taskItem = document.createElement("li");
        taskItem.textContent = taskText;
        taskItem.classList.add("task-item");
        taskItem.addEventListener("click", function() {
            taskItem.classList.toggle("completed");
        });
        taskList.appendChild(taskItem);
        taskInput.value = "";
    }
});